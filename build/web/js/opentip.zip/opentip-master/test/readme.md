# Tests

The tests are writte in coffeescript and are in the `src/` folder.

To compile them, launch `grunt js` in the project root folder.

To execute the tests, simply open the `test.html` file in a browser, or run
`npm test` in the root folder.